function circ(r)
{
  return r*10;
}

console.log(circ(10));
