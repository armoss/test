import React from 'react';

class Eventexample extends React.Component {
   constructor(props) {
      super(props);

      this.state = {
         data: ' Today is thrusday 21 june 2018......'
      }
      this.updateState = this.updateState.bind(this);
      this.resetState = this.resetState.bind(this);
   };
   updateState() {
      this.setState({data: 'Today is friday 22 june 2018...'})
   }

   resetState() {
      this.setState({data: 'Today is thrusday 21 june 2018......'})
   }
   render() {
      return (
         <div>
            <button onClick = {this.updateState}>CLICK</button>
            <button onClick = {this.resetState}>RESET</button>
            <h4>{this.state.data}</h4>
         </div>
      );
   }
}
export default Eventexample;
