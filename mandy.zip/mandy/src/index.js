import React from 'react';
import ReactDOM from 'react-dom';


import Apptest from './Apptest';


ReactDOM.render(<Apptest />, document.getElementById('root'));
