import React, { Component } from "react";
import "./Contact.css";

function Contact() {
 return (
 <div className="contact">
   <span>This is from Conact Component</span>
 </div>
 );
}

export default Contact;
