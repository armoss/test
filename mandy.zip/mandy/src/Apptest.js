import React from 'react';
import ReactDOM from 'react-dom';
import Marquee from 'react-marquee';

import Person from './Person';
import Contact from './Contact';

import ReactTimeout from 'react-timeout'
import Eventexample from './Eventexample';
import './Apptest.css'

class Apptest extends React.Component {
  constructor(){
    super();
    this.state={name:"Virat Kohli"};
  }
  render() {

    return (

      <div className="Apptest">
      <header className="header"> <p> <h1> This is React APP !!! </h1></p></header>
       Username : <input type='text' name='hfpathlist' /><br/>
       This is coming from state ==> {this.state.name}
     <br/>
    <Person/>
    <Person name="oracle"  age="40" />
    <Person name="Banner"  age="25"/>
    <Person name="Stark" age="52"> Do what you want  </Person>
    <Contact/>
    <Eventexample/>
    <p className="marquee">
     <Marquee text="this is a very very very very very very very very very very very very very very very very long text" />
     Get started with CSS styling ... </p>

      </div>


    );
  }
}

export default Apptest;
